import android.widget.Button
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp

@Composable
fun PageConnexion(onConnexionReussie: () -> Unit) {
    var nameUser by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        ChampText(
            value = nameUser,
            onValueChange = { nameUser= it },
            label = "Nom d'utilisateur"
        )

        Spacer(modifier = Modifier.height(16.dp))

        ChampText(
            value = password,
            onValueChange = { password = it },
            label = "Mot de passe",
            estMotDePasse = true
        )

        Spacer(modifier = Modifier.height(16.dp))

        ButtonConnexion(
            onClick = {
                if (nameUser == "etudiant" && password == "AzertY") {
                    error = ""
                    onConnexionReussie()
                } else {
                    error = "Nom d'utilisateur ou mot de passe incorrect"
                }
            }
        )

        if (error.isNotBlank()) {
            Text(error)
        }
    }
}

@Composable
fun ChampText(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    estMotDePasse: Boolean = false
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
        visualTransformation = if (estMotDePasse) PasswordVisualTransformation() else VisualTransformation.None
    )
}

@Composable
fun ButtonConnexion(
    onClick: () -> Unit
) {
    Button(
        onClick = onClick
    ) {
        Text("Connexion")
    }
}

@Preview
@Composable
fun PageConnexionPreview() {
    PageConnexion(onConnexionReussie = {})
}
