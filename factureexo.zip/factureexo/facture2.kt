import androidx.compose.foundation.layout.Column
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable

@Composable
fun ResultScreen(qte: Int?, pu: Float?, tva: Float?, remise: Float?,) {


    var prixTotal : Float?
    var prixHT : Float?
    prixHT= qte!! * pu!!

   prixTotal = prixHT + prixHT * tva!! /100 - prixHT * remise!!/100

    Column {
        Text(text = "Prix Total: $prixTotal")
        Button(onClick = { /* Retour à l'activité deux */ }) {
            Text("Retour")
        }
    }
}

