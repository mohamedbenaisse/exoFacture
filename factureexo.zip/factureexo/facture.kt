import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.navigation.NavHostController

@Composable
fun FactureScreen(navController: NavHostController) {
    var quantite by remember { mutableStateOf("") }
    var prixUnitaire by remember { mutableStateOf("") }
    var tauxTVA by remember { mutableStateOf("") }
    var remise by remember { mutableStateOf("") }
    var isFidele by remember { mutableStateOf("")
    }

    Column {
        TextField(
            value = quantite,
            onValueChange = { quantite=it},
            label = { Text("Quantité") })
        TextField(value = prixUnitaire, onValueChange = { prixUnitaire = it }, label = { Text("Prix unitaire") })
        TextField(value = tauxTVA, onValueChange = { tauxTVA = it }, label = { Text("Taux TVA") })






        Button(onClick = { /* Calculer TTC */ }) { navController.navigate("total/{$quantite}/{$prixUnitaire}/{$tauxTVA}/{$remise}")
            Text("Calculer TTC")
        }

        Button(onClick = {

        }) {
            Text("Remise A Zero")
        }
    }
}

@Composable
fun RadioButton(selected: Any, onClick: () -> Unit) {


}
