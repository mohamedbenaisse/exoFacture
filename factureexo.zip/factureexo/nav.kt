package com.example.factureexo

import FactureScreen
import ResultScreen
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import java.lang.reflect.Modifier

@Composable
fun Nav() {
    val navController = rememberNavController()

    NavHost(navController = navController, startDestination = "Facture")  {
        composable("Facture") {
            FactureScreen(navController)
        }

            
        
        composable(
            "total/{qte1}/{pu1}/{tva1}/{remise1}",
            arguments = listOf(
                navArgument(name = "qte1") {
                    type = NavType.IntType
                },
                navArgument(name = "pu1") {
                    type = NavType.FloatType
                },
                navArgument(name = "tva1") {
                    type = NavType.FloatType
                },
                navArgument(name = "remise1") {
                    type = NavType.FloatType
                },
            )
        )
        { backstraEntry ->
            ResultScreen(
                qte = backstraEntry.arguments?.getInt("qte1"),
                pu = backstraEntry.arguments?.getFloat("pu1"),
                tva = backstraEntry.arguments?.getFloat("tva1"),
                remise = backstraEntry.arguments?.getFloat("remise1")
            )
        }
    }
}